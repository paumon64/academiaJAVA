public class Test {
	
	public static void main (String[] args) {
		Singleton class1 = new Singleton();
		class1.test();
		
		Singleton2Random class2 = new Singleton2Random();
		class2.test();
		
	}

}
